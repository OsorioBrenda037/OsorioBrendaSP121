
package service;

import Model.Animal;
import excepcionPersonalizada.AnimalYaExisteException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Zoologico<T extends CSVSerializable> implements Almacenable<T> {
    List<T> items = new ArrayList<>();
    
    @Override
    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("El item no puede ser nulo");
        }
        
        if (items.contains(item)) {
            throw new AnimalYaExisteException();
        }
        items.add(item);
    }
    
     private void validarIndice(int indice) {
        if (indice < 0 || indice > items.size()) {
            throw new IllegalArgumentException("El indice no esta en la lista.");
        }
    }

    @Override
    public T obtener(int indice) {
        validarIndice(indice);
        return items.get(indice);
    }

    @Override
    public void eliminar(int indice) {
       validarIndice(indice);
       items.remove(indice);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> listaFiltrada = new ArrayList<>();
        
        for (T item: items) {
            if (criterio.test(item)) {
                listaFiltrada.add(item);
            }
        }
        
        return listaFiltrada;
    }

    @Override
    public void ordenar() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparator) {
        items.sort(comparator);
    }

    @Override
    public void serializar(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            
            salida.writeObject(items);
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void deserializar(String path) {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            
            items = (List<T>) input.readObject();
            
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void guardarCsv(String path) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("id, nombre, especie, alimentacio\n");
            for (T item: items) {
                bw.write(item.toCSV() + "\n");
            }
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error en archivo.");
        }
    }

    @Override
    public void cargarCsv(String path, Function<String, T> funcion) {
        items.clear();
        
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            bf.readLine();
            while ((linea = bf.readLine()) != null) {
                items.add(funcion.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error en archivo.");
        }
    }

    @Override
    public void paraCadaElemento(Consumer<T> consumidor) {
        for (T item: items) {
            consumidor.accept(item);
        }
    }

    
}
