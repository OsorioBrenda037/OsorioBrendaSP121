
package service;
//va en service
public interface CSVSerializable {
    String toCSV();
}
