
package service;

import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Almacenable<T extends CSVSerializable> {
    void agregar(T item);
    T obtener (int indice);
    void eliminar(int indice);
    List<T> filtrar(Predicate<T> criterio);
    void ordenar();
    void ordenar(Comparator<T> comparator);
    void serializar(String path);
    void deserializar(String path);
    void guardarCsv(String path);
    void cargarCsv(String path, Function<String, T> funcion);
    void paraCadaElemento(Consumer<T> consumidor);
}
