
package excepcionPersonalizada;

public class AnimalYaExisteException extends RuntimeException {
    private static final String MENSAJE = "El animal ya se encuentra en el zoologico.";

    public AnimalYaExisteException() {
        super(MENSAJE);
    }
    
    
}
