
package Model;

import java.io.Serializable;
import java.util.logging.Logger;
import service.CSVSerializable;

public class Animal implements Comparable<Animal>, Serializable, CSVSerializable {
    private static final long SerialVersionUID = 1L;
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;

    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }

    @Override
    public String toString() {
        return "Animal{" + "id=" + id + ", nombre=" + nombre + ", especie=" + especie + ", alimentacion=" + alimentacion + '}';
    }

    @Override
    public int compareTo(Animal o) {
        return Integer.compare(this.id, o.id);
    }
    
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + alimentacion.toString();
    }
    
    public static Animal fromCSV(String animalCSV) {
        String[] linea = animalCSV.split(",");
        
        if (linea.length != 4) {
            throw new IllegalArgumentException("Formato CSV incorrecto");
        }
        int id = Integer.parseInt(linea[0]);
        String nombre = linea[1];
        String especie = linea[2];
        TipoAlimentacion alimentacion = TipoAlimentacion.valueOf(linea[3].toUpperCase());
        return new Animal(id, nombre, especie, alimentacion);
    }
}
