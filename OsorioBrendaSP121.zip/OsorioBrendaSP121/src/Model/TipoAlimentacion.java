
package Model;

public enum TipoAlimentacion {
    CARNIVORO,
    HERBIVORO,
    OMNIVORO,
    INSECTIVORO;    
}
